## JSON library

This JSON library was extracted from the GRPC code. It is Apache licensed.

In the future, we can either:

1) strip out all function other than that needed to support the work of this repo, or
2) use the code in the GRPC library directly (preferred).

For now, it's here for reference and is not used in any code.

### Changes made

1. cp -p build/_deps/grpc-src/src/core/lib/json/* .
2. Changed code filenames from .cc to .cpp
3. Changed header filenames from .h to .hpp
4. Removed the code in json_utils.h (not needed)
